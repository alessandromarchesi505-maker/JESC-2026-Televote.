'use strict';

// JESC 2026 fan televote — self-hosted, dependency-free Node.js 22.13+ application.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { URL } = require('node:url');
const { DatabaseSync } = require('node:sqlite');

const EMBEDDED_FILES = {"templates/index.html":"<!doctype html>\n<html lang=\"en\">\n<head>\n  <meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">\n  <meta name=\"theme-color\" content=\"#120b2b\"><meta name=\"csrf-token\" content=\"__CSRF__\">\n  <meta name=\"description\" content=\"Vote for your three favourites in the Junior Eurovision 2026 fan televote.\">\n  <title>Televote · Junior Eurovision 2026</title>\n  <link rel=\"icon\" type=\"image/svg+xml\" href=\"/static/favicon.svg\">\n  <link rel=\"stylesheet\" href=\"/static/styles.css\">\n  <script defer src=\"/static/vote.js\"></script>\n</head>\n<body class=\"public-site\">\n  <div class=\"ambient ambient-a\" aria-hidden=\"true\"></div><div class=\"ambient ambient-b\" aria-hidden=\"true\"></div>\n  <div class=\"shell\">\n    <header class=\"topbar\">\n      <a class=\"brand\" href=\"/\" aria-label=\"Junior Eurovision Fan Televote home\">\n        <span class=\"brand-icon\" aria-hidden=\"true\"><span>✦</span></span>\n        <span class=\"brand-name\"><b>JUNIOR</b><b>EUROVISION</b><small>SONG CONTEST · 2026</small></span>\n      </a>\n      <div class=\"top-right\"><span class=\"header-tag\">FAN EDITION</span><span class=\"year-chip\">2026 <span class=\"year-star\">✳</span></span></div>\n    </header>\n\n    <main>\n      <section class=\"hero\">\n        <div class=\"hero-copy\">\n          <div class=\"eyebrow\"><span class=\"eyebrow-dot\"></span> THE TELEVOTE IS HERE <span class=\"sparkle-small\">✦</span></div>\n          <h1>YOUR VOTE.<br><span class=\"gradient-word\">THEIR MOMENT.</span></h1>\n          <p class=\"hero-description\">The stage is set. The spotlight is on. Now it’s your turn to decide who deserves your votes.</p>\n          <div class=\"status-line\"><span id=\"voting-status\" class=\"status-pill status-loading\"><span class=\"status-indicator\"></span> Checking voting status…</span><span id=\"round-label\" class=\"round-label\">ROUND 01</span></div>\n        </div>\n        <div class=\"hero-art\" aria-hidden=\"true\">\n          <div class=\"orbit orbit-one\"></div><div class=\"orbit orbit-two\"></div><div class=\"orbit orbit-three\"></div>\n          <div class=\"hero-spark hero-spark-one\">✳</div><div class=\"hero-spark hero-spark-two\">✦</div><div class=\"hero-spark hero-spark-three\">✧</div>\n          <div class=\"heart-shape\"><div class=\"heart-symbol\">♥</div></div>\n          <span class=\"orbit-text text-top\">LET YOUR VOICE SHINE</span>\n          <span class=\"orbit-text text-bottom\">JESC ✦ 2026</span>\n        </div>\n      </section>\n\n      <div class=\"marquee\" aria-label=\"Celebrate music, celebrate every voice\"><div class=\"marquee-content\">✳&nbsp; ONE STAGE &nbsp; ✦ &nbsp; MANY VOICES &nbsp; ✳ &nbsp; YOUR CHOICE &nbsp; ✦ &nbsp; ONE STAGE &nbsp; ✳ &nbsp; MANY VOICES &nbsp; ✦ &nbsp; YOUR CHOICE &nbsp; ✳</div></div>\n\n      <section class=\"vote-section\" id=\"vote-section\">\n        <div class=\"section-heading\">\n          <div><div class=\"section-kicker\">01 / CAST YOUR VOTES</div><h2>Pick your <em>top 3.</em></h2><p>Choose exactly three countries you want to support. Each selection counts as one point.</p></div>\n          <div class=\"choice-counter\" aria-live=\"polite\"><span id=\"choice-count\">0</span><span class=\"choice-divider\">/</span><span>3</span><small>SELECTED</small></div>\n        </div>\n        <div id=\"notice\" class=\"notice\" hidden></div>\n        <div id=\"countries-grid\" class=\"countries-grid\" aria-live=\"polite\"><div class=\"loading-countries\">Loading this year's countries<span class=\"loading-dots\">...</span></div></div>\n        <div class=\"how-to\"><span class=\"how-icon\">✧</span><span><strong>How it works</strong> &nbsp; Select three countries, confirm your choices, and you're done. One ballot per browser per round.</span></div>\n      </section>\n\n      <section class=\"thanks-section\" id=\"thanks-section\" hidden>\n        <div class=\"thanks-stars\">✳ &nbsp; ✦ &nbsp; ✧</div><div class=\"big-check\">✓</div><h2>THANK YOU<br><span>FOR VOTING!</span></h2><p>Your three votes have been counted. Thanks for being part of Junior Eurovision 2026!</p><div class=\"saved-badge\">✦ YOUR BALLOT IS CONFIRMED</div>\n      </section>\n    </main>\n    <footer class=\"site-footer\"><span>✦ JUNIOR EUROVISION 2026 · FAN TELEVOTE</span><span>MADE FOR THE MUSIC. POWERED BY YOU.</span><small>Independent fan-made voting site — not affiliated with the EBU or official Junior Eurovision.</small></footer>\n  </div>\n\n  <div class=\"vote-bar\" id=\"vote-bar\" hidden>\n    <div class=\"bar-inside\"><div class=\"bar-info\"><span class=\"bar-small\">YOUR SELECTION</span><div id=\"selected-chips\" class=\"selected-chips\"><span class=\"empty-chip\">Choose 3 countries</span></div></div><button type=\"button\" id=\"vote-button\" class=\"primary-btn\" disabled>SUBMIT MY VOTES <span aria-hidden=\"true\">↗</span></button></div>\n  </div>\n\n  <div id=\"confirm-overlay\" class=\"modal-backdrop\" hidden>\n    <div class=\"confirm-modal\" role=\"dialog\" aria-modal=\"true\" aria-labelledby=\"confirm-title\"><div class=\"modal-spark\">✦</div><div class=\"section-kicker\">ONE LAST CHECK</div><h2 id=\"confirm-title\">Ready to vote?</h2><p>Your choice cannot be changed after submitting.</p><div id=\"confirm-countries\" class=\"confirm-countries\"></div><div class=\"modal-buttons\"><button type=\"button\" class=\"ghost-btn\" id=\"cancel-vote\">GO BACK</button><button type=\"button\" class=\"primary-btn\" id=\"confirm-vote\">CONFIRM MY VOTES ↗</button></div><div id=\"confirm-error\" class=\"form-error\" role=\"alert\" hidden></div></div>\n  </div>\n</body>\n</html>\n","templates/admin.html":"<!doctype html>\n<html lang=\"de\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><meta name=\"theme-color\" content=\"#120b2b\"><meta name=\"csrf-token\" content=\"__CSRF__\"><title>Admin Dashboard · JESC 2026</title><link rel=\"icon\" type=\"image/svg+xml\" href=\"/static/favicon.svg\"><link rel=\"stylesheet\" href=\"/static/styles.css\"><script defer src=\"/static/admin.js\"></script></head>\n<body class=\"admin-page dashboard-page\">\n  <div class=\"dashboard-wrap\">\n    <aside class=\"sidebar\"><a href=\"/\" class=\"side-brand\"><div class=\"brand-icon\">✦</div><span><b>JUNIOR</b><b>EUROVISION</b><small>2026 ADMIN</small></span></a><div class=\"sidebar-label\">MANAGEMENT</div><a href=\"#overview\" class=\"side-link active\"><span>▣</span> Übersicht</a><a href=\"#results\" class=\"side-link\"><span>▤</span> Rangliste & Punkte</a><a href=\"#countries\" class=\"side-link\"><span>◎</span> Teilnehmerländer</a><div class=\"side-bottom\"><span class=\"side-admin-indicator\">● ADMIN-SESSION AKTIV</span><button type=\"button\" class=\"side-logout\" id=\"logout-button\">↪ Abmelden</button><a href=\"/\" class=\"side-open-link\">↗ Voting-Website öffnen</a></div></aside>\n    <div class=\"dashboard-main\">\n      <header class=\"dash-topbar\"><span class=\"section-kicker\">ORGANISER CONTROL ROOM <span class=\"top-star\">✦</span></span><div><span class=\"live-dot\"></span> <span id=\"refresh-label\">Aktualisiert automatisch</span></div></header>\n      <div class=\"dash-content\">\n        <section id=\"overview\"><div class=\"dash-page-heading\"><div><div class=\"panel-kicker\">JESC 2026 / CONTROL PANEL</div><h1>Dein <em>Dashboard.</em></h1><p>Hier kontrollierst du das Televoting und siehst alle Punkte live.</p></div><span class=\"admin-badge\">✦ ADMIN ACCESS</span></div>\n        <div id=\"admin-error\" class=\"notice notice-error\" hidden></div>\n        <div class=\"stats-grid\"><div class=\"stat-card stat-dark\"><div class=\"stat-label\">VOTING STATUS</div><div class=\"stat-value\"><span id=\"admin-status-dot\" class=\"big-state-dot\"></span><span id=\"admin-status\">LÄDT…</span></div><div class=\"stat-bottom\">Aktueller Abstimmungsstatus</div></div><div class=\"stat-card\"><div class=\"stat-label\">ABGEGEBENE STIMMZETTEL</div><div class=\"stat-value\" id=\"total-ballots\">—</div><div class=\"stat-bottom\">Jede Person wählt drei Länder</div></div><div class=\"stat-card\"><div class=\"stat-label\">VERGEBENE PUNKTE</div><div class=\"stat-value\" id=\"total-points\">—</div><div class=\"stat-bottom\">1 gewähltes Land = 1 Punkt</div></div><div class=\"stat-card\"><div class=\"stat-label\">RUNDE / TEILNEHMER</div><div class=\"stat-value\"><span id=\"current-round\">01</span><span class=\"stat-secondary\"> / <span id=\"country-count\">—</span></span></div><div class=\"stat-bottom\">Aktuelle Runde & aktive Länder</div></div></div>\n        <div class=\"control-panel\"><div class=\"control-icon\">⚡</div><div class=\"control-description\"><h2>Voting Control</h2><p id=\"control-explanation\">Öffne oder schliesse das öffentliche Voting mit einem Klick.</p></div><button type=\"button\" id=\"toggle-voting\" class=\"primary-btn\">STATUS LADEN …</button></div></section>\n\n        <section class=\"results-panel\" id=\"results\"><div class=\"panel-heading\"><div><div class=\"panel-kicker\">LIVE RESULTS</div><h2>Rangliste <em>& Punkte.</em></h2><p>Nur du kannst diese Ergebnisse sehen. Automatische Aktualisierung alle 5 Sekunden.</p></div><div class=\"panel-buttons\"><button type=\"button\" id=\"refresh-results\" class=\"secondary-btn\">↻ Aktualisieren</button><a href=\"/api/admin/export.csv\" class=\"secondary-btn\">↓ CSV Export</a></div></div><div class=\"leaderboard-head\"><span>RANG & LAND</span><span>PUNKTE</span></div><div id=\"results-list\" class=\"leaderboard-list\"><div class=\"admin-loading\">Ergebnisse werden geladen …</div></div><div class=\"results-footer\">✦ Die Ergebnisse sind auf der öffentlichen Voting-Seite nicht sichtbar.</div></section>\n\n        <section class=\"country-panel\" id=\"countries\"><div class=\"panel-heading\"><div><div class=\"panel-kicker\">PARTICIPATING COUNTRIES</div><h2>Länder <em>verwalten.</em></h2><p>Füge Länder hinzu oder blende sie vorübergehend aus.</p></div></div><form id=\"add-country-form\" class=\"country-form\"><div class=\"field\"><label for=\"country-name\">LAND</label><input type=\"text\" id=\"country-name\" placeholder=\"z. B. Switzerland\" maxlength=\"40\" required></div><div class=\"field field-code\"><label for=\"country-code\">LÄNDERCODE</label><input type=\"text\" id=\"country-code\" placeholder=\"CH\" maxlength=\"2\" pattern=\"[a-zA-Z]{2}\" required></div><button class=\"primary-btn\" type=\"submit\">+ LAND HINZUFÜGEN</button></form><div class=\"form-error\" id=\"country-error\" hidden></div><div id=\"countries-list\" class=\"manage-countries\"></div></section>\n        <section class=\"danger-panel\"><div><div class=\"panel-kicker\">NEUE ABSTIMMUNGSRUNDE</div><h3>Bei null neu starten</h3><p>Starte eine neue Runde mit 0 Punkten. Die bisherige Runde bleibt intern gespeichert. Das Voting muss dafür geschlossen sein.</p></div><button type=\"button\" class=\"secondary-btn danger-button\" id=\"new-round\">NEUE RUNDE STARTEN</button></section>\n        <footer class=\"admin-footer\">JUNIOR EUROVISION 2026 · PRIVATE FAN EVENT DASHBOARD <span>✳</span></footer>\n      </div>\n    </div>\n  </div>\n</body></html>\n","templates/login.html":"<!doctype html>\n<html lang=\"de\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><meta name=\"theme-color\" content=\"#120b2b\"><meta name=\"csrf-token\" content=\"__CSRF__\"><title>Admin Login · JESC 2026</title><link rel=\"icon\" href=\"/static/favicon.svg\" type=\"image/svg+xml\"><link rel=\"stylesheet\" href=\"/static/styles.css\"><script defer src=\"/static/admin.js\"></script></head>\n<body class=\"admin-page login-page\">\n  <div class=\"ambient ambient-a\" aria-hidden=\"true\"></div><div class=\"ambient ambient-b\" aria-hidden=\"true\"></div>\n  <main class=\"login-layout\">\n    <div class=\"login-art\"><div class=\"login-brand\"><div class=\"brand-icon\">✦</div><span>JUNIOR<br>EUROVISION<br><small>2026 FAN TELEVOTE</small></span></div><div class=\"login-spark\">✳</div><h1>TAKE<br>CONTROL<span>.</span></h1><p>Deine Show. Deine Abstimmung.<br>Alles an einem Ort.</p><div class=\"tiny-art-tag\">✦ PRIVATE ORGANISER ACCESS</div></div>\n    <div class=\"login-form-panel\"><div class=\"login-panel-top\"><a href=\"/\" class=\"back-link\">← Zur Voting-Website</a><span class=\"secure-tag\">◉ GESCHÜTZT</span></div><div class=\"login-form-center\"><div class=\"panel-kicker\">ORGANISER ONLY</div><h2>Welcome<br><em>back.</em></h2><p>Melde dich mit deinem Admin-Passwort an, um das Voting zu steuern und Punkte zu sehen.</p><form id=\"admin-login-form\"><label for=\"password\">ADMIN-PASSWORT</label><div class=\"password-wrap\"><input type=\"password\" name=\"password\" id=\"password\" placeholder=\"Dein geheimes Passwort\" autocomplete=\"current-password\" minlength=\"1\" required><button type=\"button\" id=\"toggle-password\" aria-label=\"Passwort anzeigen\">◉</button></div><button class=\"primary-btn login-submit\" type=\"submit\">ADMIN-PANEL ÖFFNEN <span>↗</span></button><p class=\"form-error\" id=\"login-error\" role=\"alert\" hidden></p></form><div class=\"login-foot\">🔒&nbsp; Die Ergebnisse sind nur nach der Anmeldung sichtbar.</div></div><div class=\"login-bottom\">JESC 2026 · FAN EVENT DASHBOARD</div></div>\n  </main>\n</body></html>\n","static/vote.js":"'use strict';\nconst csrf = document.querySelector('meta[name=\"csrf-token\"]').content;\nconst grid = document.getElementById('countries-grid');\nconst selected = new Set();\nlet state = { isOpen:false, alreadyVoted:false, countries:[], round:1 };\nlet submitting = false;\nconst escapeHtml = str => String(str).replace(/[&<>\"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',\"'\":'&#39;'}[c]));\nconst $ = id => document.getElementById(id);\nfunction message(text, kind='info') { const el=$('notice'); el.className=`notice notice-${kind}`; el.textContent=text; el.hidden=false; }\nfunction displaySuccess() { $('vote-section').hidden=true; $('vote-bar').hidden=true; $('thanks-section').hidden=false; }\nfunction refreshSelection() {\n  $('choice-count').textContent=String(selected.size);\n  $('vote-button').disabled=selected.size!==3 || !state.isOpen || state.alreadyVoted;\n  $('selected-chips').innerHTML=selected.size ? [...selected].map(id=>{\n    const c=state.countries.find(c=>c.id===id);return c?`<span class=\"selected-chip\">${escapeHtml(c.flag)} ${escapeHtml(c.name)}</span>`:'';\n  }).join('') : '<span class=\"empty-chip\">Choose 3 countries</span>';\n  grid.querySelectorAll('.country-card').forEach(button=>{\n    const id=Number(button.dataset.id), chosen=selected.has(id);\n    button.classList.toggle('selected',chosen);\n    button.setAttribute('aria-pressed',String(chosen));\n    const check=button.querySelector('.country-check');\n    check.textContent=chosen?'✓':'';\n    button.disabled=!state.isOpen || state.alreadyVoted || (selected.size===3 && !chosen);\n  });\n}\nfunction renderCountries() {\n  if (!state.countries.length) { grid.innerHTML='<div class=\"loading-countries\">No participating countries have been announced yet.</div>';return; }\n  grid.innerHTML=state.countries.map(c=>`<button type=\"button\" class=\"country-card\" data-id=\"${c.id}\" aria-pressed=\"false\"><span class=\"flag-wrap\">${escapeHtml(c.flag)}</span><span class=\"country-label\"><span class=\"country-name\">${escapeHtml(c.name)}</span><span class=\"country-code\">${escapeHtml(c.code)}</span></span><span class=\"country-check\" aria-hidden=\"true\"></span></button>`).join('');\n  grid.querySelectorAll('.country-card').forEach(button=>button.addEventListener('click',()=>{\n    if (!state.isOpen || state.alreadyVoted) return;\n    const id=Number(button.dataset.id);\n    if (selected.has(id)) selected.delete(id);\n    else if (selected.size<3) selected.add(id);\n    refreshSelection();\n  }));\n  refreshSelection();\n}\nasync function loadState() {\n  try {\n    const response=await fetch('/api/state',{cache:'no-store'});\n    if (!response.ok) throw Error('Could not check current voting status.');\n    const newer=await response.json();\n    const countriesChanged=JSON.stringify(state.countries)!==JSON.stringify(newer.countries);\n    const roundChanged=state.round!==newer.round;\n    state=newer;\n    const status=$('voting-status');\n    status.className=`status-pill ${state.alreadyVoted?'status-done':state.isOpen?'status-open':'status-closed'}`;\n    status.innerHTML='<span class=\"status-indicator\"></span>'+ (state.alreadyVoted?' VOTE SUBMITTED':state.isOpen?' VOTING IS OPEN':' VOTING IS CLOSED');\n    $('round-label').textContent=`ROUND ${String(state.round).padStart(2,'0')}`;\n    if (state.alreadyVoted) { closeConfirm();displaySuccess();return; }\n    if (roundChanged) selected.clear();\n    if (countriesChanged || roundChanged) {\n      for(const id of selected) if (!state.countries.some(c=>c.id===id)) selected.delete(id);\n      renderCountries();\n    }\n    $('vote-bar').hidden=!state.isOpen;\n    if (!state.isOpen) {\n      message('Voting is currently closed. Come back when the organiser opens the televote.','info');\n      closeConfirm();\n    } else $('notice').hidden=true;\n    refreshSelection();\n  } catch(e) { message('Could not connect to the voting server. Please try refreshing the page.','error'); }\n}\nfunction closeConfirm(){ $('confirm-overlay').hidden=true;$('confirm-error').hidden=true; }\n$('vote-button').addEventListener('click',()=>{\n  if (selected.size!==3 || !state.isOpen) return;\n  const choices=[...selected].map(id=>state.countries.find(c=>c.id===id)).filter(Boolean);\n  $('confirm-countries').innerHTML=choices.map(c=>`<div class=\"confirm-entry\"><span>${escapeHtml(c.flag)}</span>${escapeHtml(c.name)}</div>`).join('');\n  $('confirm-overlay').hidden=false;\n  $('confirm-vote').focus();\n});\n$('cancel-vote').addEventListener('click',closeConfirm);\n$('confirm-overlay').addEventListener('click',e=>{ if(e.target===$('confirm-overlay') && !submitting) closeConfirm();});\ndocument.addEventListener('keydown',e=>{if(e.key==='Escape' && !submitting)closeConfirm();});\n$('confirm-vote').addEventListener('click',async()=>{\n  if (submitting)return;\n  submitting=true;$('confirm-vote').disabled=true;$('confirm-vote').textContent='SUBMITTING…';\n  try {\n    const response=await fetch('/api/vote',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json','X-CSRF-Token':csrf},body:JSON.stringify({choices:[...selected]})});\n    const data=await response.json();\n    if (!response.ok) throw Error(data.error||'Could not submit votes.');\n    closeConfirm();state.alreadyVoted=true;displaySuccess();\n    window.scrollTo({top:350,behavior:'smooth'});\n    await loadState();\n  } catch(e) { $('confirm-error').textContent=e.message;$('confirm-error').hidden=false;await loadState(); }\n  finally { submitting=false;$('confirm-vote').disabled=false;$('confirm-vote').textContent='CONFIRM MY VOTES ↗'; }\n});\nloadState();setInterval(loadState,10000);\n","static/styles.css":":root{--navy:#130c2f;--navy2:#201147;--purple:#8755ff;--pink:#ff4da8;--cyan:#4ce9ed;--lime:#d7ff5d;--orange:#ffb95c;--paper:#f7f5fb;--ink:#1c123a;--muted:#807993;--stroke:#ece8f5;--shadow:0 24px 70px rgba(30,14,73,.13)}\n*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;font-family:Inter,\"Avenir Next\",Avenir,\"Segoe UI\",system-ui,-apple-system,sans-serif;color:var(--ink)}button,input{font:inherit}button{cursor:pointer}button:disabled{cursor:not-allowed;opacity:.55}a{text-decoration:none;color:inherit}[hidden]{display:none!important}button:focus-visible,a:focus-visible,input:focus-visible{outline:3px solid #39cfd3;outline-offset:3px}\n.public-site{background:var(--navy);color:#fff;min-height:100vh;overflow-x:hidden;position:relative}.shell{max-width:1280px;margin:auto;position:relative;z-index:2;padding:0 46px}.ambient{position:absolute;pointer-events:none;filter:blur(5px);z-index:0}.ambient-a{top:-480px;right:-350px;width:980px;height:980px;background:radial-gradient(circle,rgba(139,58,245,.29),transparent 65%)}.ambient-b{top:500px;left:-420px;width:950px;height:950px;background:radial-gradient(circle,rgba(24,173,212,.14),transparent 65%)}\n.topbar{height:108px;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid rgba(255,255,255,.11)}.brand{display:flex;align-items:center;gap:12px}.brand-icon{height:48px;width:48px;background:conic-gradient(from 40deg,var(--pink),var(--purple),var(--cyan),var(--lime),var(--pink));border-radius:17px;display:grid;place-items:center;transform:rotate(-10deg);box-shadow:0 7px 26px #ff4da84a;color:white;font-size:29px;flex-shrink:0}.brand-icon>*{transform:rotate(10deg)}.brand-name{display:grid;line-height:1.03;letter-spacing:-.8px;font-size:18px;font-weight:900}.brand-name small,.side-brand small{font-size:9px;letter-spacing:2px;font-weight:700;color:#bdb3d3;margin-top:5px}.top-right{display:flex;gap:18px;align-items:center}.header-tag{font-size:10px;font-weight:800;letter-spacing:2.2px;color:#c2b8d9}.year-chip{background:#ffffff17;border:1px solid #ffffff25;border-radius:99px;font-size:13px;font-weight:900;letter-spacing:1px;padding:12px 17px}.year-star{color:var(--lime);margin-left:6px;font-size:17px}\n.hero{min-height:500px;display:grid;grid-template-columns:1.1fr .9fr;align-items:center;padding:70px 0 60px;position:relative;gap:20px}.hero-copy{z-index:1}.eyebrow,.section-kicker,.panel-kicker{font-size:11px;letter-spacing:2.9px;font-weight:900;color:var(--cyan)}.eyebrow{display:flex;align-items:center;gap:11px}.eyebrow-dot{width:7px;height:7px;background:var(--lime);border-radius:50%;box-shadow:0 0 10px var(--lime)}.sparkle-small{color:var(--pink)}h1,h2,h3,p{margin-top:0}.hero h1{font-size:clamp(48px,5.6vw,84px);line-height:1.02;letter-spacing:-5px;font-weight:1000;margin:27px 0 24px}.gradient-word{background:linear-gradient(94deg,#ff72c6 0%,#b781ff 35%,#55deef 76%,#c9ff89);background-clip:text;-webkit-background-clip:text;color:transparent}.hero-description{color:#c1b6d6;line-height:1.85;font-size:16px;max-width:490px}.status-line{display:flex;align-items:center;gap:18px;margin-top:29px}.status-pill{border-radius:50px;padding:11px 15px;display:inline-flex;align-items:center;gap:9px;font-size:11px;letter-spacing:1.3px;font-weight:900}.status-loading{background:#fff1;color:#d2cae2;border:1px solid #ffffff33}.status-open{color:#d5ff95;background:#94f83c17;border:1px solid #b4ff753d}.status-closed{color:#ffb6d2;background:#ff5b8e18;border:1px solid #ff76a844}.status-done{color:#b9edff;background:#4cd6f52b;border:1px solid #5ce5fe44}.status-indicator{width:8px;height:8px;flex-shrink:0;background:currentColor;border-radius:50%;box-shadow:0 0 10px currentColor}.round-label{font-size:11px;font-weight:800;color:#8d81ae;letter-spacing:2px}\n.hero-art{min-height:390px;position:relative;display:flex;justify-content:center;align-items:center;isolation:isolate}.orbit{border-radius:50%;border:1px solid #ffffff24;position:absolute;left:50%;top:50%;transform:translate(-50%,-50%)}.orbit-one{width:335px;height:335px}.orbit-two{width:435px;height:435px;border-color:#ffffff13}.orbit-three{width:250px;height:250px;border-style:dashed;border-color:#b85bff6d;animation:spin 28s linear infinite}.heart-shape{width:263px;height:263px;display:grid;place-items:center;filter:drop-shadow(0 25px 65px #ea49e458);position:relative}.heart-symbol{font-size:240px;line-height:1;color:#ef4cae;text-shadow:18px -13px 0 #b259ff,-13px 17px 0 #ffb34c;transform:rotate(-12deg);animation:levitate 5s ease-in-out infinite}.heart-shape:after{content:'✦';position:absolute;top:58px;left:118px;color:white;font-size:55px;filter:drop-shadow(0 0 9px white)}.hero-spark{position:absolute;font-weight:900}.hero-spark-one{font-size:66px;top:13px;right:45px;color:var(--lime)}.hero-spark-two{font-size:55px;bottom:27px;left:46px;color:var(--cyan)}.hero-spark-three{font-size:38px;bottom:45px;right:18px;color:var(--pink)}.orbit-text{position:absolute;letter-spacing:3px;font-size:10px;font-weight:1000;color:#aaa1d2}.text-top{top:4px;left:35px;transform:rotate(-18deg)}.text-bottom{bottom:10px;right:42px;transform:rotate(-9deg)}@keyframes levitate{50%{transform:translateY(-9px) rotate(-8deg)}}@keyframes spin{to{transform:translate(-50%,-50%) rotate(360deg)}}\n.marquee{overflow:hidden;margin:0 -46px;background:linear-gradient(90deg,#ff4eab,#ad58fa,#50cce4);color:#1f1141;transform:rotate(-1.4deg);height:51px;display:flex;align-items:center;box-shadow:0 15px 40px #0002}.marquee-content{font-weight:1000;letter-spacing:2.2px;font-size:13px;white-space:nowrap;width:max-content;margin:auto}\n.vote-section{padding:96px 0 70px}.section-heading{display:flex;justify-content:space-between;align-items:end;gap:25px;margin-bottom:34px}.section-heading h2,.panel-heading h2{font-size:clamp(33px,4vw,57px);letter-spacing:-2.8px;font-weight:950;margin:12px 0 10px}.section-heading h2 em,.panel-heading h2 em,.dash-page-heading h1 em,.login-form-center h2 em{font-style:normal;color:var(--pink)}.section-heading p{color:#b3a9cb;font-size:15px;line-height:1.7;margin-bottom:0}.choice-counter{display:flex;gap:4px;align-items:baseline;position:relative;min-width:88px;white-space:nowrap;color:white;font-size:43px;font-weight:1000}.choice-counter #choice-count{color:var(--lime)}.choice-divider{color:#6b617e}.choice-counter>small{font-size:9px;position:absolute;bottom:-14px;right:2px;letter-spacing:2px;color:#aaa0c0}.countries-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px}.country-card{border:1px solid #54446d;background:linear-gradient(135deg,rgba(255,255,255,.072),rgba(255,255,255,.025));display:flex;align-items:center;text-align:left;color:white;min-height:98px;gap:17px;padding:20px 19px;border-radius:19px;transition:.18s transform,.18s background,.18s border-color;position:relative}.country-card:hover:not(:disabled){transform:translateY(-3px);background:#ffffff18;border-color:#bf8dff}.country-card.selected{border-color:var(--lime);background:linear-gradient(110deg,#d7ff5d20,#6cf7c80b);box-shadow:inset 0 0 0 1px var(--lime)}.flag-wrap{height:52px;width:52px;display:grid;place-items:center;border-radius:15px;background:#ffffff1a;border:1px solid #ffffff11;font-size:34px;flex-shrink:0}.country-label{display:flex;flex-direction:column;min-width:0}.country-name{font-size:17px;font-weight:850;letter-spacing:-.5px;overflow-wrap:anywhere}.country-code{font-size:10px;letter-spacing:2px;color:#b4a8cf;font-weight:800;margin-top:7px}.country-check{margin-left:auto;flex-shrink:0;width:23px;height:23px;border:1.5px solid #81739c;border-radius:50%;display:grid;place-items:center;font-size:13px;color:transparent}.country-card.selected .country-check{background:var(--lime);border-color:var(--lime);color:#211142;font-weight:1000}.country-card:disabled{opacity:.55;cursor:default}.loading-countries{padding:60px;color:#c9bddf;grid-column:1/-1;text-align:center}.notice{padding:17px 20px;border:1px solid #ff95ad77;border-radius:12px;background:#ff578018;color:#ffd2e0;line-height:1.5;font-size:14px;margin:20px 0}.notice-info{background:#8465ff16;border-color:#a48ffe55;color:#e1d5ff}.how-to{display:flex;gap:15px;align-items:center;margin-top:26px;padding:20px 5px;border-top:1px solid #ffffff16;color:#b9aecf;font-size:13px;line-height:1.7}.how-to strong{color:white}.how-icon{font-size:25px;color:var(--pink)}\n.vote-bar{position:fixed;bottom:20px;left:50%;width:min(100% - 32px,1100px);transform:translateX(-50%);z-index:9;border:1px solid #e6ddfa;background:rgba(255,255,255,.97);color:var(--ink);border-radius:21px;padding:14px 17px;box-shadow:0 18px 70px #0008;backdrop-filter:blur(25px)}.bar-inside{display:flex;justify-content:space-between;align-items:center;gap:16px}.bar-small{font-size:10px;font-weight:900;color:#8b7da7;letter-spacing:1.7px}.selected-chips{display:flex;flex-wrap:wrap;gap:7px;margin-top:6px}.selected-chip{background:#f3edff;border:1px solid #e0d4fc;border-radius:30px;font-size:12px;font-weight:800;padding:6px 10px;white-space:nowrap}.empty-chip{font-size:13px;color:#9c90ac}.primary-btn{border:0;border-radius:12px;padding:15px 23px;min-height:52px;background:linear-gradient(100deg,#ff5ca6,#b551f1);color:#fff;font-weight:950;font-size:11px;letter-spacing:1.1px;box-shadow:0 9px 25px #b145e13d;transition:transform .18s,filter .18s;white-space:nowrap}.primary-btn:hover:not(:disabled){transform:translateY(-2px);filter:brightness(1.07)}.primary-btn span{font-size:18px;margin-left:8px;vertical-align:-1px}.primary-btn:disabled{background:#c7bfd0;box-shadow:none;color:#fff;opacity:1}\n.modal-backdrop{position:fixed;z-index:30;inset:0;background:#0b0628cc;backdrop-filter:blur(7px);display:grid;place-items:center;padding:16px}.confirm-modal{width:min(100%,475px);position:relative;border:1px solid #ffffff34;background:#241447;border-radius:28px;box-shadow:0 30px 100px #0009;text-align:center;color:#fff;padding:39px 35px;overflow:hidden}.modal-spark{font-size:39px;color:var(--lime);margin-bottom:4px}.confirm-modal h2{font-size:34px;letter-spacing:-1.5px;margin:13px 0}.confirm-modal p{font-size:14px;color:#bdacd8}.confirm-countries{margin:25px 0;display:grid;gap:9px}.confirm-entry{padding:11px 15px;background:#ffffff10;border:1px solid #ffffff15;border-radius:13px;font-weight:850;text-align:left}.confirm-entry span{font-size:25px;margin-right:10px}.modal-buttons{display:flex;gap:10px}.ghost-btn{background:#ffffff13;border:1px solid #ffffff32;border-radius:12px;padding:12px 16px;color:white;font-size:11px;font-weight:900;letter-spacing:1px}.modal-buttons>*{flex:1}.thanks-section{margin:50px 0 70px;text-align:center;border:1px solid #ffffff2e;border-radius:32px;padding:70px 25px;background:radial-gradient(circle at 50% 30%,#ae64ed4a,transparent 55%),#1c103c}.thanks-stars{font-size:37px;color:var(--lime)}.big-check{width:75px;height:75px;margin:20px auto;background:var(--lime);display:grid;place-items:center;border-radius:50%;color:var(--navy);font-size:40px;font-weight:900}.thanks-section h2{font-size:clamp(45px,6vw,72px);line-height:1;letter-spacing:-3px;margin:10px 0 20px}.thanks-section h2 span{color:var(--pink)}.thanks-section p{color:#c6bbd6;max-width:430px;margin:0 auto 28px;line-height:1.8}.saved-badge{display:inline-block;border:1px solid #b8ffac67;background:#baffab15;color:#caffba;font-size:10px;font-weight:900;letter-spacing:2px;padding:15px 20px;border-radius:40px}.site-footer{padding:35px 0 110px;border-top:1px solid #ffffff18;display:flex;gap:15px;justify-content:space-between;flex-wrap:wrap;font-size:10px;font-weight:850;letter-spacing:1.4px;color:#a79ac0}.site-footer small{width:100%;color:#817391;font-size:10px;letter-spacing:.2px;font-weight:400}\n/* Login */\n.admin-page{background:#f8f7fc;color:var(--ink);min-height:100vh}.login-page{overflow-x:hidden}.login-layout{display:grid;grid-template-columns:1fr 1fr;min-height:100vh}.login-art{background:radial-gradient(circle at 80% 20%,#773bbc80,transparent 36%),radial-gradient(circle at 10% 90%,#1fafd455,transparent 32%),#170d36;color:white;position:relative;overflow:hidden;padding:50px 7%;display:flex;flex-direction:column;justify-content:space-between}.login-art:before,.login-art:after{content:'';position:absolute;width:480px;height:480px;border:1px solid #ffffff30;border-radius:50%;right:-150px;top:20%;pointer-events:none}.login-art:after{width:350px;height:350px;right:-80px;top:26%;border-style:dashed}.login-brand{display:flex;align-items:center;gap:15px;font-size:21px;font-weight:1000;line-height:1.01;letter-spacing:-.8px;z-index:1}.login-brand small{font-size:9px;letter-spacing:2px;color:#bfb4d4}.login-spark{position:absolute;top:30%;right:15%;font-size:115px;color:var(--lime);transform:rotate(15deg);text-shadow:0 0 100px #9bf9b5;z-index:1}.login-art h1{font-size:clamp(70px,9.2vw,145px);line-height:.88;letter-spacing:-7px;margin:0;position:relative;z-index:2}.login-art h1 span{color:var(--pink)}.login-art p{color:#b5a7cf;line-height:1.8;margin-top:24px;z-index:2;font-size:16px}.tiny-art-tag{font-size:10px;letter-spacing:2px;color:#c9b9e2;z-index:2}.login-form-panel{display:flex;flex-direction:column;padding:35px 7%}.login-panel-top{display:flex;justify-content:space-between;gap:10px;align-items:center}.back-link{font-size:12px;font-weight:750;color:#827794}.back-link:hover{color:#8d58ef}.secure-tag{font-size:10px;letter-spacing:1px;font-weight:900;color:#3c957a;background:#e5fbef;border-radius:30px;padding:9px 11px}.login-form-center{width:min(100%,405px);margin:auto}.panel-kicker{color:#a34ef0}.login-form-center h2{font-size:clamp(51px,5.2vw,76px);line-height:1;letter-spacing:-4px;margin:16px 0 24px}.login-form-center>p{color:#847994;line-height:1.75;font-size:15px;margin-bottom:43px}.login-form-center label,.field label{display:block;font-size:10px;font-weight:900;letter-spacing:1.8px;color:#766c86;margin-bottom:11px}.password-wrap{position:relative}.password-wrap input,.country-form input{height:57px;border:1px solid #e2ddea;border-radius:12px;background:white;color:#20153b;width:100%;padding:0 18px;outline:0}.password-wrap input:focus,.country-form input:focus{border-color:#ae6af4;box-shadow:0 0 0 3px #b66dff17}.password-wrap button{position:absolute;right:14px;top:12px;border:0;background:#f3edfb;border-radius:9px;width:33px;height:33px;color:#8e7ca4}.login-submit{margin-top:18px;width:100%;display:flex;align-items:center;justify-content:space-between}.login-foot{font-size:12px;color:#847a92;line-height:1.6;margin-top:31px}.login-bottom{font-size:10px;letter-spacing:1.5px;color:#aaa0b3}.form-error{padding:12px;margin-top:15px;background:#fff0f3;color:#b9255c;border:1px solid #ffd2de;border-radius:10px;font-size:13px}\n/* Admin dashboard */\n.dashboard-wrap{display:grid;grid-template-columns:250px minmax(0,1fr);min-height:100vh}.sidebar{background:var(--navy);color:white;padding:33px 21px;display:flex;flex-direction:column;position:sticky;top:0;height:100vh;min-height:650px}.side-brand{display:flex;align-items:center;gap:11px;padding:5px 9px 50px}.side-brand .brand-icon{width:41px;height:41px;border-radius:12px;font-size:22px}.side-brand>span{display:grid;line-height:1.07;font-size:16px;letter-spacing:-.4px}.side-brand small{font-size:9px}.sidebar-label{color:#776d98;font-size:9px;font-weight:950;letter-spacing:2px;padding:0 15px 15px}.side-link{padding:15px 14px;border-radius:12px;display:flex;align-items:center;gap:14px;color:#ada0ce;font-size:13px;font-weight:750;margin-bottom:5px}.side-link>span{font-size:20px;width:20px}.side-link:hover,.side-link.active{background:#ffffff15;color:white}.side-link.active{border:1px solid #ffffff11}.side-bottom{margin-top:auto;display:grid;gap:13px;padding:0 7px}.side-admin-indicator{color:#bbd6a2;font-size:9px;letter-spacing:1.2px;font-weight:850;margin:0 5px 10px}.side-logout{background:#ffffff0e;border:1px solid #ffffff20;color:white;padding:13px;border-radius:10px;font-size:12px;text-align:left}.side-open-link{color:#a899c5;font-size:11px;text-align:center}.dashboard-main{min-width:0}.dash-topbar{height:73px;display:flex;align-items:center;justify-content:space-between;padding:0 45px;border-bottom:1px solid #eae6f0;background:white}.dash-topbar .section-kicker{color:#8d67ad;font-size:10px}.top-star{color:var(--pink)}.dash-topbar>div{font-size:11px;color:#968b9f;font-weight:700}.live-dot{display:inline-block;width:8px;height:8px;border-radius:50%;background:#69cd8f;margin-right:4px}.dash-content{padding:48px min(5%,65px);max-width:1510px;margin:auto}.dash-page-heading{display:flex;justify-content:space-between;align-items:center;gap:20px;margin-bottom:31px}.dash-page-heading h1{font-size:clamp(38px,4vw,59px);line-height:1.1;letter-spacing:-2.5px;margin:12px 0 11px}.dash-page-heading p,.panel-heading p{color:#8a8298;font-size:14px;line-height:1.7;margin:0}.admin-badge{background:#e9e0ff;color:#8556ba;border-radius:30px;padding:11px 14px;font-size:10px;font-weight:900;letter-spacing:1px;white-space:nowrap}.stats-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:13px}.stat-card{border:1px solid #ebe6f2;background:#fff;border-radius:18px;padding:23px 19px;min-width:0;min-height:171px;display:flex;flex-direction:column;box-shadow:0 3px 9px #25103c06}.stat-dark{background:linear-gradient(125deg,#201042,#392265);color:white;border-color:transparent}.stat-label{font-size:9px;letter-spacing:1.1px;font-weight:900;color:#9b91ac;line-height:1.5}.stat-dark .stat-label{color:#b3a2d9}.stat-value{display:flex;align-items:center;gap:9px;font-size:clamp(24px,2.8vw,40px);font-weight:950;letter-spacing:-1.9px;margin:13px 0 0}.stat-dark .stat-value{font-size:clamp(22px,2.6vw,36px);letter-spacing:-1.2px}.big-state-dot{height:12px;width:12px;background:#f299a9;border-radius:50%;box-shadow:0 0 15px #ff738a}.big-state-dot.is-open{background:#c7fd65;box-shadow:0 0 15px #bafb72}.stat-secondary{font-size:24px;color:#b8add0}.stat-bottom{font-size:11px;line-height:1.5;color:#a198ae;margin-top:auto;padding-top:14px}.stat-dark .stat-bottom{color:#c1b2dc}.control-panel{border-radius:20px;padding:25px;margin-top:20px;display:flex;gap:19px;align-items:center;background:linear-gradient(105deg,#fff,#f3efff);border:1px solid #e7dff5}.control-icon{height:52px;width:52px;display:grid;place-items:center;border-radius:15px;background:#e7dcff;font-size:28px;color:#7e4fe3;flex-shrink:0}.control-description{flex:1}.control-description h2{font-size:21px;letter-spacing:-.5px;margin:0 0 6px}.control-description p{color:#91869f;font-size:12px;line-height:1.55;margin:0}.control-panel .primary-btn{min-width:175px}.control-panel .close-btn{background:#23123f;box-shadow:none}\n.results-panel,.country-panel{background:#fff;border:1px solid #e9e4ef;border-radius:23px;margin-top:28px;overflow:hidden;box-shadow:0 4px 20px #2a1f3a05}.panel-heading{padding:29px 29px 23px;display:flex;justify-content:space-between;align-items:center;gap:17px}.panel-heading h2{font-size:32px;letter-spacing:-1.4px;margin:10px 0}.panel-buttons{display:flex;gap:8px;flex-wrap:wrap;justify-content:end}.secondary-btn{border:1px solid #e0d7e9;border-radius:10px;background:white;color:#4f4166;font-size:11px;font-weight:900;letter-spacing:.2px;padding:12px 14px;white-space:nowrap}.secondary-btn:hover{background:#f6f0ff;border-color:#ceb6ef}.leaderboard-head{display:flex;justify-content:space-between;color:#9d92ae;background:#f9f7fc;border-top:1px solid #ece7f4;border-bottom:1px solid #ece7f4;padding:14px 30px;font-size:9px;letter-spacing:2px;font-weight:900}.leaderboard-list{padding:1px 26px}.leader-row{display:grid;grid-template-columns:minmax(0,1fr) minmax(80px,1fr) 72px;gap:15px;align-items:center;padding:16px 5px;border-bottom:1px solid #f0edf5}.leader-row:last-child{border-bottom:0}.leader-ident{display:flex;align-items:center;gap:14px;min-width:0}.leader-rank{color:#a99eaf;width:18px;flex-shrink:0;font-size:11px;font-weight:900}.rank-one{color:#c28820}.rank-two{color:#7a7e9c}.rank-three{color:#ba8156}.leader-flag{font-size:28px}.leader-name{font-size:13px;font-weight:850;overflow-wrap:anywhere}.inactive-mark{color:#a99cae;font-size:10px;margin-left:5px}.bar-track{height:8px;border-radius:30px;background:#f0eaf9;overflow:hidden}.bar-fill{height:100%;border-radius:30px;background:linear-gradient(90deg,#b34af5,#fb5cab);min-width:0}.leader-row:first-child .bar-fill{background:linear-gradient(90deg,#ffbb57,#ff5ca5)}.leader-points{text-align:right;font-weight:950;font-size:20px;letter-spacing:-.7px}.leader-points small{display:block;font-weight:700;font-size:9px;letter-spacing:1px;color:#a49ab1}.results-footer{padding:16px 30px;background:#fcfbff;border-top:1px solid #f0eaf9;color:#9a8ca9;font-size:11px}.admin-loading{padding:40px;text-align:center;color:#998ca9;font-size:13px}.country-form{margin:0 29px 20px;background:#f7f4fc;border:1px solid #efe9f7;padding:15px;border-radius:14px;display:flex;gap:12px;align-items:end}.field{flex:1;min-width:100px}.field-code{flex:0 0 130px}.country-form input{height:48px;font-size:13px}.country-form .primary-btn{height:48px;min-height:48px}.country-panel .form-error{margin:0 29px 20px}.manage-countries{margin:0 29px 25px;display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.manage-row{min-width:0;border:1px solid #ece6f1;border-radius:12px;padding:11px 12px;display:flex;align-items:center;gap:10px}.manage-row.off{opacity:.65;background:#f7f4f9}.manage-flag{font-size:25px}.manage-ident{flex:1;min-width:0}.manage-ident strong{display:block;font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.manage-ident span{font-size:10px;color:#ab9ab6}.manage-actions{display:flex;gap:5px}.tiny-btn{border:1px solid #e2dbe9;border-radius:7px;color:#5b4d6d;background:#fff;font-size:10px;font-weight:800;padding:8px}.tiny-btn:hover{border-color:#a87ded}.tiny-btn.delete{color:#c85d78}.danger-panel{border-radius:19px;padding:22px 26px;display:flex;align-items:center;gap:20px;justify-content:space-between;margin-top:27px;border:1px dashed #d9cbd9;background:#fbf9fc}.danger-panel h3{margin:9px 0 5px;font-size:17px}.danger-panel p{margin:0;color:#95869e;max-width:620px;font-size:12px;line-height:1.6}.danger-button{color:#a64c6e}.admin-footer{display:flex;justify-content:space-between;margin:36px 0 10px;color:#a79bb4;letter-spacing:1.5px;font-size:9px;font-weight:900}.admin-footer span{font-size:22px;color:var(--pink)}\n@media(max-width:1100px){.stats-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.dash-content{padding:35px 30px}.country-form{flex-wrap:wrap}.country-form .primary-btn{width:100%}.hero h1{letter-spacing:-3px}}\n@media(max-width:850px){.shell{padding:0 25px}.hero{grid-template-columns:1fr;min-height:unset;padding:63px 0 45px}.hero-art{position:absolute;right:-110px;top:-35px;opacity:.28;width:460px;z-index:0;pointer-events:none}.hero-copy{position:relative}.hero-description{max-width:490px}.marquee{margin:0 -25px}.countries-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.dashboard-wrap{grid-template-columns:1fr}.sidebar{position:relative;height:auto;min-height:0;padding:16px;display:flex;flex-direction:row;align-items:center;gap:4px;overflow-x:auto}.side-brand{padding:0 15px 0 0}.side-brand .brand-icon{width:32px;height:32px}.side-brand>span{font-size:11px}.sidebar-label,.side-bottom{display:none}.side-link{padding:11px 10px;white-space:nowrap;font-size:11px;margin-bottom:0}.side-link>span{display:none}.dash-topbar{padding:0 26px;height:56px}.login-art{padding:35px}.login-art h1{font-size:80px;letter-spacing:-5px}.login-form-panel{padding:25px 7%}}\n@media(max-width:600px){.shell{padding:0 17px}.topbar{height:86px}.brand-icon{width:40px;height:40px;border-radius:12px}.brand-name{font-size:14px}.brand-name small{font-size:7px;letter-spacing:1.4px}.header-tag{display:none}.year-chip{padding:9px 12px;font-size:11px}.hero{padding-top:58px}.hero h1{font-size:clamp(43px,10.3vw,61px);letter-spacing:-2.7px;margin:23px 0 19px}.hero-description{font-size:14px}.hero-art{right:-210px;top:-37px}.marquee{margin:0 -17px}.marquee-content{font-size:11px}.vote-section{padding-top:68px}.section-heading{align-items:center}.section-heading h2{font-size:33px;letter-spacing:-1.6px}.section-heading p{font-size:13px}.choice-counter{font-size:32px;min-width:64px}.countries-grid{gap:9px}.country-card{padding:12px;min-height:85px;gap:9px;border-radius:14px}.flag-wrap{width:39px;height:39px;font-size:27px;border-radius:12px}.country-name{font-size:12px;letter-spacing:-.5px}.country-code{font-size:9px;margin-top:4px}.country-check{width:18px;height:18px;font-size:11px}.how-to{font-size:12px}.vote-bar{bottom:10px;padding:12px;width:calc(100% - 18px)}.bar-inside{align-items:stretch}.vote-bar .primary-btn{font-size:10px;padding:12px;white-space:normal;line-height:1.25;max-width:160px}.selected-chip{font-size:10px;padding:5px 7px}.bar-small{font-size:9px}.site-footer{padding-bottom:140px;font-size:9px}.confirm-modal{padding:34px 20px}.modal-buttons{flex-direction:column}.login-layout{display:flex;flex-direction:column}.login-art{min-height:250px;padding:25px 24px}.login-brand{font-size:15px}.login-art .brand-icon{height:36px;width:36px}.login-art h1{font-size:55px;letter-spacing:-3px;margin-top:30px}.login-art p,.tiny-art-tag{display:none}.login-spark{font-size:65px;right:30px;top:45%}.login-form-panel{min-height:570px;padding:25px 25px}.login-form-center{padding-top:35px}.login-form-center h2{font-size:59px}.sidebar{padding:10px}.side-brand{padding-right:8px}.side-link{font-size:10px;padding:11px 7px}.dash-topbar .section-kicker{font-size:8px}.dash-topbar>div{font-size:9px}.dash-content{padding:28px 14px}.dash-page-heading h1{font-size:39px}.dash-page-heading p{font-size:12px}.admin-badge{display:none}.stats-grid{gap:8px}.stat-card{padding:16px 13px;min-height:149px}.stat-label{font-size:8px}.stat-value{font-size:29px}.stat-dark .stat-value{font-size:24px}.stat-bottom{font-size:10px}.control-panel{padding:18px;flex-wrap:wrap;gap:10px}.control-icon{width:40px;height:40px}.control-description h2{font-size:18px}.control-panel .primary-btn{width:100%}.panel-heading{flex-direction:column;align-items:flex-start;padding:23px 18px 18px}.panel-heading h2{font-size:30px}.panel-buttons{justify-content:flex-start}.leaderboard-head{padding:12px 19px}.leaderboard-list{padding:0 15px}.leader-row{grid-template-columns:minmax(0,1fr) 55px 46px;gap:9px}.leader-ident{gap:8px}.leader-name{font-size:11px}.leader-flag{font-size:22px}.leader-points{font-size:16px}.manage-countries{margin:0 16px 20px;grid-template-columns:1fr}.country-form{margin:0 16px 18px}.country-form .field-code{flex:0 0 90px}.danger-panel{flex-direction:column;align-items:start;padding:20px}.danger-button{width:100%}.results-footer{padding:14px 19px}}\n@media(prefers-reduced-motion:reduce){*{scroll-behavior:auto!important;animation:none!important;transition:none!important}}\n\n@media(max-width:400px){.country-card{gap:7px;padding:10px}.country-check{width:17px;height:17px}.country-name{font-size:11.5px;letter-spacing:-.45px}.section-heading{gap:12px}}\n","static/admin.js":"'use strict';\nconst csrf=document.querySelector('meta[name=\"csrf-token\"]').content;\nconst $=id=>document.getElementById(id);\nconst esc=s=>String(s).replace(/[&<>\"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',\"'\":'&#39;'}[c]));\nasync function api(path,data){const response=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':csrf},body:JSON.stringify(data),credentials:'same-origin'});let body={};try{body=await response.json();}catch{}if(!response.ok)throw Error(body.error||'Anfrage fehlgeschlagen.');return body;}\nif($('admin-login-form')) {\n  const form=$('admin-login-form');\n  $('toggle-password').addEventListener('click',()=>{$('password').type=$('password').type==='password'?'text':'password';});\n  form.addEventListener('submit',async e=>{\n    e.preventDefault();const button=form.querySelector('[type=\"submit\"]');const error=$('login-error');button.disabled=true;button.textContent='BITTE WARTEN …';error.hidden=true;\n    try{await api('/admin/login',{password:$('password').value});window.location.assign('/admin');}\n    catch(err){error.textContent=err.message;error.hidden=false;button.disabled=false;button.innerHTML='ADMIN-PANEL ÖFFNEN <span>↗</span>';}\n  });\n}\nif($('results-list')) {\n  let info=null,working=false;\n  function report(msg){const el=$('admin-error');el.textContent=msg;el.hidden=false;window.scrollTo({top:0,behavior:'smooth'});}\n  function render(data) {\n    info=data;\n    $('admin-error').hidden=true;\n    $('admin-status').textContent=data.isOpen?'OFFEN':'GESCHLOSSEN';\n    $('admin-status-dot').classList.toggle('is-open',data.isOpen);\n    $('total-ballots').textContent=data.totalBallots.toLocaleString('de-CH');\n    $('total-points').textContent=data.totalPoints.toLocaleString('de-CH');\n    $('current-round').textContent=String(data.round).padStart(2,'0');\n    $('country-count').textContent=String(data.activeCount);\n    const toggle=$('toggle-voting');toggle.textContent=data.isOpen?'✕ VOTING SCHLIESSEN':'✦ VOTING ÖFFNEN';toggle.classList.toggle('close-btn',data.isOpen);\n    $('control-explanation').textContent=data.isOpen?'Das Voting ist offen. Zuschauer können momentan abstimmen.':'Das Voting ist geschlossen. Es werden keine Stimmen angenommen.';\n    const max=Math.max(1,...data.results.map(c=>c.points));\n    $('results-list').innerHTML=data.results.length?data.results.map((c,i)=>`<div class=\"leader-row\"><div class=\"leader-ident\"><span class=\"leader-rank ${i<3?'rank-'+['one','two','three'][i]:''}\">${String(i+1).padStart(2,'0')}</span><span class=\"leader-flag\">${esc(c.flag)}</span><span class=\"leader-name\">${esc(c.name)}${c.active?'':'<span class=\"inactive-mark\">(inaktiv)</span>'}</span></div><div class=\"bar-track\"><div class=\"bar-fill\" style=\"width:${c.points?Math.max(2,(100*c.points/max)):0}%\"></div></div><div class=\"leader-points\">${c.points}<small>PKT.</small></div></div>`).join(''):'<div class=\"admin-loading\">Noch keine Länder vorhanden.</div>';\n    $('countries-list').innerHTML=[...data.results].sort((a,b)=>a.name.localeCompare(b.name)).map(c=>`<div class=\"manage-row ${c.active?'':'off'}\"><span class=\"manage-flag\">${esc(c.flag)}</span><span class=\"manage-ident\"><strong>${esc(c.name)}</strong><span>${esc(c.code)} · ${c.active?'Aktiv':'Ausgeblendet'} · ${c.points} Pkt.</span></span><span class=\"manage-actions\"><button class=\"tiny-btn\" data-action=\"toggle\" data-id=\"${c.id}\">${c.active?'Ausbl.':'Zeigen'}</button><button class=\"tiny-btn delete\" data-action=\"delete\" data-id=\"${c.id}\" title=\"Land entfernen\">✕</button></span></div>`).join('');\n    $('refresh-label').textContent='Live · '+new Date().toLocaleTimeString('de-CH',{hour:'2-digit',minute:'2-digit',second:'2-digit'});\n  }\n  async function refresh(quiet=false) {\n    if(working)return;\n    try{const r=await fetch('/api/admin/dashboard',{cache:'no-store'});if(r.status===401){location.href='/admin';return;}if(!r.ok)throw Error('Daten konnten nicht geladen werden.');render(await r.json());}\n    catch(e){if(!quiet)report(e.message);}\n  }\n  async function doAction(fn) {\n    if(working)return;working=true;\n    try{await fn();await refreshForced();}\n    catch(e){report(e.message);}finally{working=false;}\n  }\n  async function refreshForced(){const r=await fetch('/api/admin/dashboard',{cache:'no-store'});if(!r.ok)throw Error('Daten konnten nicht geladen werden.');render(await r.json());}\n  $('toggle-voting').addEventListener('click',()=>{\n    if(!info)return;\n    doAction(async()=>await api('/api/admin/status',{open:!info.isOpen}));\n  });\n  $('refresh-results').addEventListener('click',()=>refresh());\n  $('add-country-form').addEventListener('submit',e=>{\n    e.preventDefault();const name=$('country-name').value.trim(),code=$('country-code').value.trim();\n    const error=$('country-error');error.hidden=true;\n    doAction(async()=>{\n      try{await api('/api/admin/countries',{name,code});$('add-country-form').reset();}\n      catch(err){error.textContent=err.message;error.hidden=false;throw err;}\n    });\n  });\n  $('countries-list').addEventListener('click',e=>{\n    const button=e.target.closest('button[data-action]');if(!button||!info)return;\n    const id=Number(button.dataset.id),action=button.dataset.action;\n    const c=info.results.find(c=>c.id===id);if(!c)return;\n    if(action==='delete'&&!window.confirm(`„${c.name}“ wirklich entfernen? Länder mit Stimmen können nur ausgeblendet werden.`))return;\n    doAction(async()=>await api(`/api/admin/countries/${id}/${action}`,{}));\n  });\n  $('new-round').addEventListener('click',()=>{\n    if(!info)return;\n    if(info.isOpen){report('Bitte zuerst das Voting schliessen.');return;}\n    if(!window.confirm(`Eine neue Abstimmungsrunde ${info.round+1} mit 0 Punkten starten? Die alte Runde bleibt gespeichert.`))return;\n    doAction(async()=>await api('/api/admin/new-round',{confirm:'NEW ROUND'}));\n  });\n  $('logout-button').addEventListener('click',()=>doAction(async()=>{await api('/admin/logout',{});location.assign('/admin');}));\n  refresh();setInterval(()=>refresh(true),5000);\n}\n","static/favicon.svg":"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 64 64\"><defs><linearGradient id=\"g\" x1=\"0\" x2=\"1\" y1=\"1\" y2=\"0\"><stop stop-color=\"#ff4ba1\"/><stop offset=\".55\" stop-color=\"#a350ff\"/><stop offset=\"1\" stop-color=\"#45dafa\"/></linearGradient></defs><rect width=\"64\" height=\"64\" rx=\"18\" fill=\"#1b1041\"/><path d=\"M32 51C20 43 10 34 10 24c0-7 5-12 12-12 5 0 8 2 10 6 2-4 6-6 11-6 7 0 11 5 11 12 0 10-10 19-22 27Z\" fill=\"url(#g)\"/><path d=\"m32 14 3.5 10.5L46 28l-10.5 3.5L32 42l-3.5-10.5L18 28l10.5-3.5Z\" fill=\"#fff\"/></svg>\n"};

const ROOT = __dirname;
const envFile = path.join(ROOT, '.env');
if (fs.existsSync(envFile)) {
  for (const line of fs.readFileSync(envFile, 'utf8').split(/\r?\n/)) {
    const match = line.match(/^\s*([A-Z_][A-Z_0-9]*)=(.*)\s*$/);
    if (match && !Object.hasOwn(process.env, match[1])) process.env[match[1]] = match[2].trim();
  }
}

// Railway-friendly configuration. Attach a persistent volume at /app/data.
const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '0.0.0.0';
const COOKIE_SECURE = process.env.COOKIE_SECURE !== 'false';
const DB_PATH = process.env.DB_PATH
  ? path.resolve(ROOT, process.env.DB_PATH)
  : path.join(ROOT, 'data', 'votes.sqlite');
fs.mkdirSync(path.dirname(DB_PATH), {recursive:true});
const SECRET_PATH = path.join(path.dirname(DB_PATH), '.jesc-secret');
let SECRET = process.env.SECRET_KEY;
if (!SECRET) {
  if (fs.existsSync(SECRET_PATH)) SECRET = fs.readFileSync(SECRET_PATH, 'utf8').trim();
  else {
    SECRET = crypto.randomBytes(48).toString('hex');
    fs.writeFileSync(SECRET_PATH, SECRET, {flag:'wx', mode:0o600});
  }
}
if (SECRET.length < 32) throw new Error('SECRET_KEY muss mindestens 32 Zeichen lang sein');
const PASSWORD_HASH = process.env.ADMIN_PASSWORD_HASH || (() => {
  const pw = process.env.ADMIN_PASSWORD;
  if (!pw || pw.length < 12) {
    console.error('Bitte in Railway unter Variables ADMIN_PASSWORD mit mindestens 12 Zeichen setzen.');
    process.exit(1);
  }
  const salt = crypto.randomBytes(16);
  return `scrypt$${salt.toString('hex')}$${crypto.scryptSync(pw,salt,64).toString('hex')}`;
})();
const db = new DatabaseSync(DB_PATH);
db.exec('PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;');
db.exec(`
  CREATE TABLE IF NOT EXISTS settings (name TEXT PRIMARY KEY, value TEXT NOT NULL);
  CREATE TABLE IF NOT EXISTS countries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    active INTEGER NOT NULL DEFAULT 1
  );
  CREATE TABLE IF NOT EXISTS ballots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    round INTEGER NOT NULL,
    voter_hash TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE (round, voter_hash)
  );
  CREATE TABLE IF NOT EXISTS ballot_choices (
    ballot_id INTEGER NOT NULL REFERENCES ballots(id) ON DELETE CASCADE,
    country_id INTEGER NOT NULL REFERENCES countries(id),
    PRIMARY KEY (ballot_id, country_id)
  );
  CREATE TABLE IF NOT EXISTS login_attempts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ip_hash TEXT NOT NULL,
    created_at INTEGER NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_login_attempts ON login_attempts(ip_hash, created_at);
  INSERT OR IGNORE INTO settings(name, value) VALUES ('voting_open','0'),('round','1');
`);
if (db.prepare('SELECT COUNT(*) AS count FROM countries').get().count === 0) {
  const seed = db.prepare('INSERT INTO countries(code,name) VALUES (?,?)');
  for (const [code, name] of [
    ['MD', 'Moldova'], ['SE', 'Sweden'], ['HR', 'Croatia'],
    ['GR', 'Greece'], ['PT', 'Portugal'], ['GE', 'Georgia'],
  ]) seed.run(code, name);
}

const getSetting = (name) => db.prepare('SELECT value FROM settings WHERE name=?').get(name)?.value;
const setSetting = (name, value) => db.prepare('UPDATE settings SET value=? WHERE name=?').run(String(value), name);
const getRound = () => Number(getSetting('round'));
const openNow = () => getSetting('voting_open') === '1';
const allCountries = () => db.prepare('SELECT id, code, name, active FROM countries ORDER BY name COLLATE NOCASE').all();
const flag = (code) => /^[A-Z]{2}$/.test(code)
  ? String.fromCodePoint(...[...code].map(c => c.charCodeAt(0) + 127397)) : '🎤';
const publicCountry = c => ({ id: c.id, code: c.code, name: c.name, flag: flag(c.code) });
const escapeHtml = value => String(value).replace(/[&<>"']/g, char =>
  ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' })[char]);

function hmac(input) {
  return crypto.createHmac('sha256', SECRET).update(input).digest('base64url');
}
function sign(input) {
  const encoded = Buffer.from(input).toString('base64url');
  return `${encoded}.${hmac(encoded)}`;
}
function unsign(cookie) {
  if (!cookie || typeof cookie !== 'string') return null;
  const i = cookie.lastIndexOf('.');
  if (i < 1) return null;
  const encoded = cookie.slice(0, i), signature = cookie.slice(i + 1);
  const expected = hmac(encoded);
  const a = Buffer.from(signature), b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a,b)) return null;
  try { return Buffer.from(encoded, 'base64url').toString('utf8'); }
  catch { return null; }
}
function parseCookies(header = '') {
  const out = {};
  for (const part of header.split(';')) {
    const eq = part.indexOf('=');
    if (eq < 1) continue;
    const key = part.slice(0, eq).trim();
    try { out[key] = decodeURIComponent(part.slice(eq + 1).trim()); } catch { /* ignore */ }
  }
  return out;
}
function cookie(name, value, maxAge) {
  return `${name}=${encodeURIComponent(value)}; Path=/; Max-Age=${maxAge}; HttpOnly; SameSite=Lax${COOKIE_SECURE ? '; Secure' : ''}`;
}
function prepareRequest(req, res) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; style-src-attr 'unsafe-inline'; img-src 'self' data:; base-uri 'none'; frame-ancestors 'none'; form-action 'self'");
  const cookies = parseCookies(req.headers.cookie);
  let vid = unsign(cookies.jesc_vid);
  let csrf = unsign(cookies.jesc_csrf);
  const set = [];
  if (!vid || !/^[a-f0-9]{48}$/.test(vid)) {
    vid = crypto.randomBytes(24).toString('hex');
    set.push(cookie('jesc_vid', sign(vid), 365 * 86400));
  }
  if (!csrf || !/^[a-f0-9]{48}$/.test(csrf)) {
    csrf = crypto.randomBytes(24).toString('hex');
    set.push(cookie('jesc_csrf', sign(csrf), 365 * 86400));
  }
  req.clientContext = { vid, csrf, cookies };
  req.isAdmin = false;
  const admin = unsign(cookies.jesc_admin);
  if (admin) {
    try {
      const session = JSON.parse(admin);
      req.isAdmin = session.admin === true && Number.isFinite(session.exp) && session.exp > Date.now();
    } catch { /* ignore */ }
  }
  if (set.length) res.setHeader('Set-Cookie', set);
}
function appendCookie(res, str) {
  const existing = res.getHeader('Set-Cookie') || [];
  res.setHeader('Set-Cookie', [...existing, str]);
}
function json(res, code, obj) {
  res.writeHead(code, { 'Content-Type':'application/json; charset=utf-8' });
  res.end(JSON.stringify(obj));
}
function error(res, code, message) { json(res, code, { error: message }); }
function isAdmin(req, res) {
  if (req.isAdmin) return true;
  error(res, 401, 'Bitte zuerst als Admin anmelden.'); return false;
}
function validCsrf(req) {
  const provided = req.headers['x-csrf-token'];
  if (typeof provided !== 'string') return false;
  const a = Buffer.from(provided), b = Buffer.from(req.clientContext.csrf);
  return a.length === b.length && crypto.timingSafeEqual(a,b);
}
function needCsrf(req, res) {
  if (validCsrf(req)) return true;
  error(res, 403, 'Sicherheitsprüfung fehlgeschlagen. Bitte Seite neu laden.'); return false;
}
function voterHash(vid) {
  return crypto.createHash('sha256').update(SECRET).update(':').update(vid).digest('hex');
}
function alreadyVoted(req) {
  return !!db.prepare('SELECT id FROM ballots WHERE round=? AND voter_hash=?').get(getRound(), voterHash(req.clientContext.vid));
}
function sendPage(res, filename, values = {}) {
  let html = EMBEDDED_FILES['templates/' + filename];
  for (const [key, value] of Object.entries(values)) html = html.replaceAll(`__${key}__`, escapeHtml(value));
  res.writeHead(200, { 'Content-Type':'text/html; charset=utf-8' });
  res.end(html);
}
function staticFile(res, pathname) {
  const allowed = { '/static/styles.css':'text/css; charset=utf-8',
    '/static/vote.js':'application/javascript; charset=utf-8',
    '/static/admin.js':'application/javascript; charset=utf-8',
    '/static/favicon.svg':'image/svg+xml' };
  if (!allowed[pathname]) return false;
  const content = EMBEDDED_FILES[pathname.slice(1)];
  res.writeHead(200, { 'Content-Type':allowed[pathname], 'Cache-Control':'public, max-age=900' });
  res.end(content); return true;
}
async function readJson(req) {
  let raw = '';
  for await (const chunk of req) {
    raw += chunk;
    if (raw.length > 16000) throw new Error('Die Anfrage ist zu gross.');
  }
  let body;
  try { body = JSON.parse(raw || '{}'); } catch { throw new Error('Ungültige Daten.'); }
  if (!body || typeof body !== 'object' || Array.isArray(body)) throw new Error('Ungültige Daten.');
  return body;
}
function transaction(fn) {
  db.exec('BEGIN IMMEDIATE');
  try { const value = fn(); db.exec('COMMIT'); return value; }
  catch (e) { db.exec('ROLLBACK'); throw e; }
}
function dashboardData() {
  const round = getRound();
  const totalBallots = db.prepare('SELECT COUNT(*) AS count FROM ballots WHERE round=?').get(round).count;
  const votes = db.prepare(`
    SELECT bc.country_id, COUNT(*) AS points
    FROM ballot_choices bc JOIN ballots b ON b.id = bc.ballot_id
    WHERE b.round=? GROUP BY bc.country_id
  `).all(round);
  const points = new Map(votes.map(v => [v.country_id, v.points]));
  const results = allCountries().map(c => ({ ...publicCountry(c), active:!!c.active, points:points.get(c.id) || 0 }))
    .sort((a,b) => b.points - a.points || a.name.localeCompare(b.name));
  return { isOpen:openNow(), round, totalBallots, totalPoints:totalBallots*3,
    results, activeCount:results.filter(c => c.active).length };
}
function rateKey(req) {
  const addr = req.socket.remoteAddress || 'unknown';
  return crypto.createHash('sha256').update(SECRET).update(addr).digest('hex');
}
function verifyAdminPassword(password) {
  const [type, saltHex, digestHex] = PASSWORD_HASH.split('$');
  if (type !== 'scrypt' || !/^[a-f\d]{32}$/.test(saltHex || '') || !/^[a-f\d]{128}$/.test(digestHex || '')) return false;
  const candidate = crypto.scryptSync(password, Buffer.from(saltHex,'hex'), 64);
  return crypto.timingSafeEqual(candidate, Buffer.from(digestHex,'hex'));
}
function csvEscape(value) { return `"${String(value).replaceAll('"','""')}"`; }

const server = http.createServer(async (req,res) => {
  prepareRequest(req,res);
  const pathname = new URL(req.url, 'http://localhost').pathname;
  const method = req.method;
  try {
    if (method === 'GET' && staticFile(res,pathname)) return;
    if (method === 'GET' && pathname === '/') return sendPage(res, 'index.html', { CSRF:req.clientContext.csrf });
    if (method === 'GET' && pathname === '/admin') return sendPage(res, req.isAdmin ? 'admin.html' : 'login.html', { CSRF:req.clientContext.csrf });
    if (method === 'GET' && pathname === '/health') return json(res, 200, {ok:true});
    if (method === 'GET' && pathname === '/robots.txt') { res.writeHead(200, {'Content-Type':'text/plain'}); return res.end('User-agent: *\nDisallow: /admin\n'); }
    if (method === 'GET' && pathname === '/api/state') {
      return json(res, 200, { isOpen:openNow(), alreadyVoted:alreadyVoted(req),
        countries:allCountries().filter(c=>c.active).map(publicCountry), round:getRound() });
    }
    if (method === 'POST' && pathname === '/api/vote') {
      if (!needCsrf(req,res)) return;
      const body = await readJson(req);
      const choices = body.choices;
      if (!Array.isArray(choices) || choices.length !== 3 || choices.some(v=>!Number.isSafeInteger(v)) || new Set(choices).size !== 3) {
        return error(res, 400, 'Bitte genau drei verschiedene Länder auswählen.');
      }
      let result;
      try {
        result = transaction(() => {
          if (!openNow()) return { code:409, message:'Das Voting ist momentan geschlossen.' };
          const round = getRound(), vid = voterHash(req.clientContext.vid);
          if (db.prepare('SELECT id FROM ballots WHERE round=? AND voter_hash=?').get(round, vid))
            return { code:409, message:'Du hast in dieser Runde bereits abgestimmt.' };
          const active = new Set(allCountries().filter(c=>c.active).map(c=>c.id));
          if (choices.some(id=>!active.has(id))) return { code:400, message:'Ein gewähltes Land ist nicht mehr verfügbar.' };
          const ballot = db.prepare('INSERT INTO ballots (round, voter_hash) VALUES (?,?)').run(round,vid);
          const insert = db.prepare('INSERT INTO ballot_choices (ballot_id, country_id) VALUES (?,?)');
          for (const id of choices) insert.run(ballot.lastInsertRowid,id);
          return { code:200, data:{success:true, message:'Deine Stimmen wurden gezählt. Vielen Dank!'} };
        });
      } catch (e) {
        if (e.code?.startsWith('SQLITE_CONSTRAINT')) return error(res,409,'Du hast bereits abgestimmt.');
        throw e;
      }
      if (result.code !== 200) return error(res,result.code,result.message);
      return json(res,200,result.data);
    }
    if (method === 'POST' && pathname === '/admin/login') {
      if (!needCsrf(req,res)) return;
      const body = await readJson(req);
      const password = body.password;
      if (typeof password !== 'string' || password.length > 500) return error(res,400,'Ungültiges Passwort.');
      const key=rateKey(req), now=Math.floor(Date.now()/1000);
      db.prepare('DELETE FROM login_attempts WHERE created_at < ?').run(now-900);
      const tries=db.prepare('SELECT COUNT(*) AS count FROM login_attempts WHERE ip_hash=?').get(key).count;
      if (tries >= 8) return error(res,429,'Zu viele Versuche. Bitte in 15 Minuten erneut versuchen.');
      if (!verifyAdminPassword(password)) {
        db.prepare('INSERT INTO login_attempts(ip_hash,created_at) VALUES (?,?)').run(key,now);
        return error(res,401,'Das Passwort ist nicht korrekt.');
      }
      db.prepare('DELETE FROM login_attempts WHERE ip_hash=?').run(key);
      appendCookie(res,cookie('jesc_admin',sign(JSON.stringify({admin:true,exp:Date.now()+2*86400000})),2*86400));
      return json(res,200,{success:true});
    }
    if (method === 'POST' && pathname === '/admin/logout') {
      if (!needCsrf(req,res)) return;
      appendCookie(res,cookie('jesc_admin','',0));
      return json(res,200,{success:true});
    }
    if (pathname.startsWith('/api/admin/')) {
      if (!isAdmin(req,res)) return;
      if (method === 'GET' && pathname === '/api/admin/dashboard') return json(res,200,dashboardData());
      if (method === 'GET' && pathname === '/api/admin/export.csv') {
        const data=dashboardData();
        const rows=[['Rank','Country','Code','Points','Votes','Active'], ...data.results.map((c,i)=>[i+1,c.name,c.code,c.points,c.points,c.active?'yes':'no'])];
        const csv='\ufeff'+rows.map(row=>row.map(csvEscape).join(',')).join('\r\n');
        res.writeHead(200, { 'Content-Type':'text/csv; charset=utf-8',
          'Content-Disposition':`attachment; filename="jesc-2026-round-${data.round}-points.csv"` });
        return res.end(csv);
      }
      if (method !== 'POST') return error(res,405,'Nicht erlaubt.');
      if (!needCsrf(req,res)) return;
      const body = await readJson(req);
      if (pathname === '/api/admin/status') {
        if (typeof body.open !== 'boolean') return error(res,400,'Ungültiger Status.');
        const count=allCountries().filter(c=>c.active).length;
        if (body.open && count<3) return error(res,400,'Du brauchst mindestens drei aktive Länder.');
        transaction(()=>setSetting('voting_open',body.open?'1':'0'));
        return json(res,200,{success:true,isOpen:openNow()});
      }
      if (pathname === '/api/admin/countries') {
        const code=String(body.code || '').trim().toUpperCase();
        const name=String(body.name || '').trim().replace(/\s+/g,' ');
        if (!/^[A-Z]{2}$/.test(code) || name.length<2 || name.length>40 || /[<>\u0000-\u001f]/.test(name))
          return error(res,400,'Bitte einen Namen (2–40 Zeichen) und einen Ländercode (z. B. CH) eingeben.');
        try { db.prepare('INSERT INTO countries (code,name) VALUES (?,?)').run(code,name); }
        catch(e) { if (e.code?.startsWith('SQLITE_CONSTRAINT')) return error(res,409,'Dieser Ländercode existiert bereits.'); throw e; }
        return json(res,200,{success:true});
      }
      const match=pathname.match(/^\/api\/admin\/countries\/(\d+)\/(toggle|delete)$/);
      if (match) {
        const id=Number(match[1]), action=match[2];
        const c=db.prepare('SELECT * FROM countries WHERE id=?').get(id);
        if (!c) return error(res,404,'Land nicht gefunden.');
        const activeCount=allCountries().filter(c=>c.active).length;
        if (c.active && activeCount<=3) return error(res,409,'Mindestens drei Länder müssen aktiv bleiben.');
        if (action === 'toggle') {
          db.prepare('UPDATE countries SET active=? WHERE id=?').run(c.active?0:1,id);
          return json(res,200,{success:true});
        }
        const historicVotes=db.prepare('SELECT COUNT(*) AS count FROM ballot_choices WHERE country_id=?').get(id).count;
        if (historicVotes) return error(res,409,'Dieses Land hat bereits Stimmen. Du kannst es nur ausblenden.');
        db.prepare('DELETE FROM countries WHERE id=?').run(id);
        return json(res,200,{success:true});
      }
      if (pathname === '/api/admin/new-round') {
        if (openNow()) return error(res,409,'Schliesse zuerst die Abstimmung.');
        if (body.confirm !== 'NEW ROUND') return error(res,400,'Bitte die neue Runde bestätigen.');
        transaction(()=>setSetting('round',getRound()+1));
        return json(res,200,{success:true,round:getRound()});
      }
    }
    return error(res,404,'Seite nicht gefunden.');
  } catch(e) {
    console.error('Request failed:',e);
    if (!res.headersSent) error(res, e.message && ['Ungültige Daten.','Die Anfrage ist zu gross.'].includes(e.message)?400:500,
      e.message && ['Ungültige Daten.','Die Anfrage ist zu gross.'].includes(e.message)?e.message:'Ein Serverfehler ist aufgetreten.');
    else res.end();
  }
});
server.listen(PORT,HOST,()=>console.log(`\n🎤 JESC 2026 Televote listening at http://localhost:${PORT}\nAdmin: http://localhost:${PORT}/admin\n`));
